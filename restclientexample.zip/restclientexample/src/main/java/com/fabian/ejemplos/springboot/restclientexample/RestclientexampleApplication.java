package com.fabian.ejemplos.springboot.restclientexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestclientexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestclientexampleApplication.class, args);
	}

}
