package com.fabian.ejemplos.springboot.restclientexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestclientexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
